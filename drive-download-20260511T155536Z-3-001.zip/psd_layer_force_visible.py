#!/usr/bin/env python3
"""
psd_layer_force_visible.py – Extracts ALL layers, forcing hidden ones visible
Usage: python psd_layer_force_visible.py comic.psd output_folder
"""

import sys
import os
from psd_tools import PSDImage

def extract_layers_force_visible(input_path, output_folder):
    try:
        psd = PSDImage.open(input_path)
        print(f"Loaded PSD: {input_path}")

        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        for i, layer in enumerate(psd.descendants()):
            if layer.is_group():
                continue  # skip groups
            # Temporarily force visibility
            original_visibility = layer.visible
            layer.visible = True
            try:
                image = layer.composite()
                if image:
                    safe_name = layer.name.replace(" ", "_") or f"unnamed_{i}"
                    filename = os.path.join(output_folder, f"layer_{i}_{safe_name}.png")
                    image.save(filename)
                    print(f"Saved: {filename}")
            except Exception as e:
                print(f"Layer {i} failed: {e}")
            finally:
                # Restore original visibility
                layer.visible = original_visibility

        print("Forced layer extraction complete.")

    except Exception as e:
        print(f"Extraction failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python psd_layer_force_visible.py input.psd output_folder")
    else:
        extract_layers_force_visible(sys.argv[1], sys.argv[2])